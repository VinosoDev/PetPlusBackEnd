package com.tcc.petPlusBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetPlusBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
